package com.example.dineshyalla.ibuy.model;

public class ProductClientClass {
    int id;
    String productName;
    int productprice;
    int weight;
    int aisleNo;

    public int getId() {
        return id;
    }

    public String getProductName() {
        return productName;
    }

    public int getProductprice() {
        return productprice;
    }

    public int getWeight() {
        return weight;
    }

    public int getAisleNo() {
        return aisleNo;
    }
}
